# 数据质量报告

- 状态：PASS_WITH_WARNINGS
- 检查时间：2026-07-21T05:36:26.591363+00:00
- 评估日期：2026-07-20
- 错误数：0
- 警告数：2
- 信息数：13

## 文件

- 价格数据：`D:\Work\AITradingSystem\data\raw\prices_daily.csv`，行数=56548，日期范围=2018-01-02 至 2026-07-17，sha256=b9c9633794ca01762d1b4eecd2310343776c4413897df3c73faa02a2b7708542
- 第二行情源 Marketstack：`D:\Work\AITradingSystem\data\raw\prices_marketstack_daily.csv`，行数=52019，日期范围=2018-01-02 至 2026-07-17，sha256=460b94166dacfc56f02d2cc6c5627542cd8f7ea9dede3404693aa10ff29fc901
- FRED 宏观序列：`D:\Work\AITradingSystem\data\raw\rates_daily.csv`，行数=6394，日期范围=2018-01-02 至 2026-07-16，sha256=d530a35e810d78643753d84c7b6ef4bcfe9a7911402425e1aeccf76eff8c2658
- 下载审计清单：`D:\Work\AITradingSystem\data\raw\download_manifest.csv`，行数=1040，日期范围=n/a 至 n/a，sha256=3703a1c5f8858e6088b8b138a7e6d400877d4ebfcabc8bf17a25b887ddb2825c

## 预期覆盖范围

- 价格标的：SPY, QQQ, SMH, SOXX, TLT, SHY, TQQQ, SGOV, ^VIX, MSFT, GOOG, TSM, INTC, AMD, NVDA, AMZN, META, AVGO, MRVL, ASML, AMAT, LRCX, MU, PLTR, CRM, NOW
- FRED 宏观序列：DGS2, DGS10, DTWEXBGS
- 价格一致性检查起点：2021-02-22（早于该日期的价格一致性差异不阻断默认日报）
- 宏观变化检查起点：2021-02-22（早于该日期的宏观变化差异不提示默认日报）

## 问题

| 级别 | 来源 | Code | 行数 | 说明 | 样例 |
|---|---|---|---:|---|---|
| 警告 | 下载审计清单 | prices_download_manifest_checksum_missing |  | 价格数据当前文件 sha256 未出现在下载审计清单中；请确认缓存是否由 download-data 生成。 | D:\Work\AITradingSystem\data\raw\prices_daily.csv |
| 信息 | 价格主源 | prices_index_volume_not_applicable | 2177 | 价格数据缺少成交量，但该 ticker 已配置为指数/非成交标的，volume 不适用于质量阻断。 | {'date': '2018-01-02', 'ticker': '^VIX', 'volume': nan}; {'date': '2018-01-03', 'ticker': '^VIX', 'volume': nan}; {'date': '2018-01-04', 'ticker': '^VIX', 'volume': nan} |
| 信息 | 价格主源 | prices_suspicious_adj_close_move | 24 | 价格数据包含较大调整收盘价单日波动；未达到极端错误阈值，作为可审计市场波动信息记录。 | {'date': '2025-04-09', 'ticker': 'AMD', 'adj_close': 96.84, '_return': 0.23820483314154206, '_suspicious_return_threshold': 0.2}; {'date': '2025-10-06', 'ticker': 'AMD', 'adj_close': 203.71, '_return': 0.23708022104815707, '_suspicious_return_threshold': 0.2}; {'date': '2024-12-13', 'ticker': 'AVGO', 'adj_close': 221.38, '_return': 0.2443370243381484, '_suspicious_return_threshold': 0.2} |
| 信息 | 价格主源 | prices_known_split_adjustment_ratio_jump | 6 | 复权比例跳变匹配已配置 corporate action 拆股事件。 | {'date': '2024-07-15', 'ticker': 'AVGO', '_adjustment_ratio': 0.9815657449539144, '_adjustment_ratio_change': 8.999693677028406}; {'date': '2024-10-03', 'ticker': 'LRCX', '_adjustment_ratio': 0.9860683023055111, '_adjustment_ratio_change': 9.00072511407645}; {'date': '2025-12-18', 'ticker': 'NOW', '_adjustment_ratio': 1.0, '_adjustment_ratio_change': 4.0} |
| 警告 | 价格主源 | prices_adjustment_ratio_jump | 6 | 价格数据的复权比例出现明显跳变 | {'date': '2022-06-06', 'ticker': 'AMZN', '_adjustment_ratio': 1.0, '_adjustment_ratio_change': 19.0}; {'date': '2022-07-18', 'ticker': 'GOOG', '_adjustment_ratio': 0.9912655809298517, '_adjustment_ratio_change': 19.000898114413918}; {'date': '2022-07-18', 'ticker': 'GOOGL', '_adjustment_ratio': 0.9911950839218563, '_adjustment_ratio_change': 18.999239436964817} |
| 信息 | 第二行情源 Marketstack | prices_non_positive_close | 14 | 价格数据的 close 包含非正数 | {'date': '2026-04-07', 'ticker': 'META', 'close': 0.0}; {'date': '2026-04-08', 'ticker': 'META', 'close': 0.0}; {'date': '2026-06-04', 'ticker': 'META', 'close': 0.0} |
| 信息 | 第二行情源 Marketstack | prices_non_positive_adj_close | 14 | 价格数据的 adj_close 包含非正数 | {'date': '2026-04-07', 'ticker': 'META', 'adj_close': 0.0}; {'date': '2026-04-08', 'ticker': 'META', 'adj_close': 0.0}; {'date': '2026-06-04', 'ticker': 'META', 'adj_close': 0.0} |
| 信息 | 第二行情源 Marketstack | prices_invalid_ohlc | 28 | 价格数据违反 OHLC 逻辑约束 | {'date': '2026-01-13', 'ticker': 'AMAT', 'open': 301.81, 'high': 310.6413, 'low': 302.59, 'close': 304.87}; {'date': '2025-12-17', 'ticker': 'CRM', 'open': 256.33, 'high': 261.97, 'low': 256.37, 'close': 258.14}; {'date': '2025-12-29', 'ticker': 'CRM', 'open': 264.71, 'high': 269.11, 'low': 265.0, 'close': 266.23} |
| 信息 | 第二行情源 Marketstack | prices_extreme_adj_close_move | 6 | 价格数据包含极端的调整收盘价单日波动 | {'date': '2024-07-12', 'ticker': 'AVGO', 'adj_close': 170.087, '_return': -0.9002977812948797, '_extreme_return_threshold': 0.5}; {'date': '2024-10-02', 'ticker': 'LRCX', 'adj_close': 81.409, '_return': -0.8979043868669894, '_extreme_return_threshold': 0.5}; {'date': '2025-12-17', 'ticker': 'NOW', 'adj_close': 156.478, '_return': -0.7996748258910282, '_extreme_return_threshold': 0.5} |
| 信息 | 第二行情源 Marketstack | prices_suspicious_adj_close_move | 25 | 价格数据包含较大调整收盘价单日波动；未达到极端错误阈值，作为可审计市场波动信息记录。 | {'date': '2025-04-09', 'ticker': 'AMD', 'adj_close': 96.84, '_return': 0.23820483314154206, '_suspicious_return_threshold': 0.2}; {'date': '2025-10-06', 'ticker': 'AMD', 'adj_close': 203.71, '_return': 0.23708022104815707, '_suspicious_return_threshold': 0.2}; {'date': '2024-12-13', 'ticker': 'AVGO', 'adj_close': 224.8, '_return': 0.24432635890623278, '_suspicious_return_threshold': 0.2} |
| 信息 | 第二行情源 Marketstack | prices_known_split_adjustment_ratio_jump | 7 | 复权比例跳变匹配已配置 corporate action 拆股事件。 | {'date': '2024-07-12', 'ticker': 'AVGO', '_adjustment_ratio': 0.1, '_adjustment_ratio_change': -0.9}; {'date': '2024-07-15', 'ticker': 'AVGO', '_adjustment_ratio': 1.0, '_adjustment_ratio_change': 9.0}; {'date': '2024-10-02', 'ticker': 'LRCX', '_adjustment_ratio': 0.1, '_adjustment_ratio_change': -0.9} |
| 信息 | 第二行情源 Marketstack | prices_adjustment_ratio_jump | 3 | 价格数据的复权比例出现明显跳变 | {'date': '2022-06-06', 'ticker': 'AMZN', '_adjustment_ratio': 1.0, '_adjustment_ratio_change': 19.0}; {'date': '2022-07-18', 'ticker': 'GOOG', '_adjustment_ratio': 1.0, '_adjustment_ratio_change': 19.0}; {'date': '2021-07-20', 'ticker': 'NVDA', '_adjustment_ratio': 0.099819471308833, '_adjustment_ratio_change': 2.999988725667067} |
| 信息 | 跨源核验：主价格源 vs Marketstack | secondary_prices_known_split_close_basis | 1 | 主价格缓存与 Marketstack 的未调整收盘价差异匹配已配置拆股事件，按 corporate-action window 日期口径差异记录，不改写价格缓存。 | {'date': '2025-12-17', 'ticker': 'NOW', '_primary_close': 782.4, '_secondary_close': 156.478, '_close_diff_pct': 0.8000025562372188} |
| 信息 | 跨源核验：主价格源 vs Marketstack | secondary_prices_adjustment_basis_warning | 9451 | Marketstack 调整收盘价与主缓存差异超过错误阈值，但未调整收盘价通过核验；这通常表示供应商 adjusted close 分红调整口径不同，需在报告中保留限制说明。 | {'date': '2021-02-22', 'ticker': 'ASML', '_primary_close': 578.5, '_secondary_close': 578.5, '_close_diff_pct': 0.0, '_primary_adj_close': 550.88, '_secondary_adj_close': 578.5, '_adj_close_diff_pct': 0.050137961080453104}; {'date': '2021-02-23', 'ticker': 'ASML', '_primary_close': 576.07, '_secondary_close': 576.07, '_close_diff_pct': 0.0, '_primary_adj_close': 548.56, '_secondary_adj_close': 576.07, '_adj_close_diff_pct': 0.05014948228088105}; {'date': '2021-02-24', 'ticker': 'ASML', '_primary_close': 595.01, '_secondary_close': 595.01, '_close_diff_pct': 0.0, '_primary_adj_close': 566.6, '_secondary_adj_close': 595.01, '_adj_close_diff_pct': 0.05014119308153895} |
| 信息 | 跨源核验：主价格源 vs Marketstack | secondary_prices_adjustment_basis_info | 9715 | Marketstack 调整收盘价与主缓存超过警告阈值，但未调整收盘价通过核验；按分红复权口径差异记录。 | {'date': '2021-02-22', 'ticker': 'AMAT', '_primary_close': 115.23, '_secondary_close': 115.23, '_close_diff_pct': 0.0, '_primary_adj_close': 110.08, '_secondary_adj_close': 115.23, '_adj_close_diff_pct': 0.04678415697674424}; {'date': '2021-02-23', 'ticker': 'AMAT', '_primary_close': 116.14, '_secondary_close': 116.14, '_close_diff_pct': 0.0, '_primary_adj_close': 110.95, '_secondary_adj_close': 116.14, '_adj_close_diff_pct': 0.046777827850383036}; {'date': '2021-02-24', 'ticker': 'AMAT', '_primary_close': 122.81, '_secondary_close': 122.81, '_close_diff_pct': 0.0, '_primary_adj_close': 117.54, '_secondary_adj_close': 122.81, '_adj_close_diff_pct': 0.04483580057852642} |

## Marketstack reconciliation

- 明细 CSV：与本 Markdown 同目录，文件名后缀为 `_marketstack_reconciliation.csv`。
- 规则边界：只归因和记录，不改写主价格缓存、第二行情源缓存、评分或回测真值。

| 级别 | 分类 | 行数 |
|---|---|---:|
| 信息 | adjusted_close_dividend_basis_difference | 19166 |
| 信息 | known_split_raw_close_basis_difference | 1 |
| 信息 | marketstack_bad_point_primary_available | 28 |

### 样例

| 日期 | Ticker | 级别 | 分类 | 规则 | 证据 |
|---|---|---|---|---|---|
| 2026-01-13 | AMAT | 信息 | marketstack_bad_point_primary_available | marketstack.secondary_self_check.v1 | Marketstack row violates close/adj_close/OHLC self-check; primary source same ticker-date is recorded for audit when available. |
| 2025-12-17 | CRM | 信息 | marketstack_bad_point_primary_available | marketstack.secondary_self_check.v1 | Marketstack row violates close/adj_close/OHLC self-check; primary source same ticker-date is recorded for audit when available. |
| 2025-12-29 | CRM | 信息 | marketstack_bad_point_primary_available | marketstack.secondary_self_check.v1 | Marketstack row violates close/adj_close/OHLC self-check; primary source same ticker-date is recorded for audit when available. |
| 2026-05-12 | CRM | 信息 | marketstack_bad_point_primary_available | marketstack.secondary_self_check.v1 | Marketstack row violates close/adj_close/OHLC self-check; primary source same ticker-date is recorded for audit when available. |
| 2026-05-13 | CRM | 信息 | marketstack_bad_point_primary_available | marketstack.secondary_self_check.v1 | Marketstack row violates close/adj_close/OHLC self-check; primary source same ticker-date is recorded for audit when available. |
| 2026-01-13 | INTC | 信息 | marketstack_bad_point_primary_available | marketstack.secondary_self_check.v1 | Marketstack row violates close/adj_close/OHLC self-check; primary source same ticker-date is recorded for audit when available. |
| 2026-01-14 | LRCX | 信息 | marketstack_bad_point_primary_available | marketstack.secondary_self_check.v1 | Marketstack row violates close/adj_close/OHLC self-check; primary source same ticker-date is recorded for audit when available. |
| 2026-02-02 | LRCX | 信息 | marketstack_bad_point_primary_available | marketstack.secondary_self_check.v1 | Marketstack row violates close/adj_close/OHLC self-check; primary source same ticker-date is recorded for audit when available. |
| 2026-04-07 | META | 信息 | marketstack_bad_point_primary_available | marketstack.secondary_self_check.v1 | Marketstack row violates close/adj_close/OHLC self-check; primary source same ticker-date is recorded for audit when available. |
| 2026-04-08 | META | 信息 | marketstack_bad_point_primary_available | marketstack.secondary_self_check.v1 | Marketstack row violates close/adj_close/OHLC self-check; primary source same ticker-date is recorded for audit when available. |
